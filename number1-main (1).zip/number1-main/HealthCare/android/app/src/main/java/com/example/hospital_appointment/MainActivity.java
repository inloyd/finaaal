package com.example.hospital_appointment;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
