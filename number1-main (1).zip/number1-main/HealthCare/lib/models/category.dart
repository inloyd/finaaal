class Category {
  var icon;
  var title;
  double imageSize;


  Category({
    required this.icon,
    required this.title,
    required this.imageSize,
  });
}
