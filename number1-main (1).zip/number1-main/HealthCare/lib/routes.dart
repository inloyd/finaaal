import 'Screens/splash_view.dart';

const String SplashRoute = "/splash";

final routes = {
  SplashRoute: (context) => SplashView(),
};
